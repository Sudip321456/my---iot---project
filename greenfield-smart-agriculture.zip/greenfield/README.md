# GreenField Smart Agriculture (Flask)

Features: live sensor dashboard, 24h charts (Chart.js), alerts, crop manager (add/update/remove),
pump control with Manual/Auto mode and activity log, crop advice, live weather (Open-Meteo, no key needed),
SQLite storage, and a REST API for real sensors.

## Run locally
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                   # open http://127.0.0.1:5000
```

## Connect real sensors (ESP32 / Raspberry Pi)
```bash
curl -X POST http://YOUR-SERVER/api/readings -H "Content-Type: application/json" \
  -H "X-API-Key: change-me" -d '{"temp":29.5,"humidity":61,"soil":38,"rain":20}'
```
Set `API_KEY` in the environment so only your devices can post.

## Deploy (Render)
1. Push this folder to GitHub.
2. Render > New Web Service > Build: `pip install -r requirements.txt` > Start: `gunicorn app:app`.
3. Add env vars from `.env.example`. SQLite is wiped on redeploy on free plans: attach a
   persistent disk and set `DATABASE_PATH=/var/data/greenfield.db`, or move to Postgres.

## Endpoints
GET /api/summary · GET/POST /api/readings · POST /api/readings/simulate · GET/POST /api/crops ·
PUT/DELETE /api/crops/<id> · GET/POST /api/pump · POST /api/advice · GET /api/weather · GET /health
