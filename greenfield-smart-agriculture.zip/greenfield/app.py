import json, os, random, sqlite3, urllib.request
from datetime import datetime, timedelta, timezone
from flask import Flask, g, jsonify, render_template, request

app = Flask(__name__)
BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("DATABASE_PATH", os.path.join(BASE, "greenfield.db"))
LAT, LON = os.environ.get("FARM_LAT", "22.57"), os.environ.get("FARM_LON", "88.36")
API_KEY = os.environ.get("API_KEY", "")

SCHEMA = """
CREATE TABLE IF NOT EXISTS readings(id INTEGER PRIMARY KEY, ts TEXT, temp REAL, humidity REAL, soil REAL, rain REAL);
CREATE TABLE IF NOT EXISTS crops(id INTEGER PRIMARY KEY, name TEXT, field TEXT, stage TEXT, progress INTEGER);
CREATE TABLE IF NOT EXISTS pump(id INTEGER PRIMARY KEY CHECK(id=1), is_on INTEGER, mode TEXT);
CREATE TABLE IF NOT EXISTS irrigation_log(id INTEGER PRIMARY KEY, ts TEXT, action TEXT, source TEXT);
"""
# Ideal soil-moisture ranges (%) per crop, used by the advice endpoint
RANGES = {"rice": (60, 85), "wheat": (35, 60), "vegetables": (40, 65), "maize": (40, 60), "tomato": (45, 65)}


def now():
    return datetime.now(timezone.utc)


def iso(d):
    return d.strftime("%Y-%m-%dT%H:%M:%SZ")


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()


def init_db():
    c = sqlite3.connect(DB)
    c.executescript(SCHEMA)
    if not c.execute("SELECT COUNT(*) FROM crops").fetchone()[0]:
        c.executemany("INSERT INTO crops(name,field,stage,progress) VALUES(?,?,?,?)",
                      [("Rice", "Field A", "Vegetative", 68), ("Wheat", "Field B", "Early growth", 34),
                       ("Vegetables", "Field C", "Mixed vegetables", 82)])
        c.execute("INSERT INTO pump VALUES(1,0,'manual')")
        t, s = now() - timedelta(hours=24), 45.0
        for i in range(25):  # seed 24h of demo history
            s = max(15, min(85, s + random.uniform(-4, 3)))
            c.execute("INSERT INTO readings(ts,temp,humidity,soil,rain) VALUES(?,?,?,?,?)",
                      (iso(t + timedelta(hours=i)), round(24 + 6 * random.random(), 1),
                       round(55 + 20 * random.random(), 1), round(s, 1), round(random.uniform(5, 60))))
    c.commit()
    c.close()


def rows(q, a=()):
    return [dict(r) for r in db().execute(q, a).fetchall()]


def latest():
    r = rows("SELECT * FROM readings ORDER BY id DESC LIMIT 1")
    return r[0] if r else None


def alerts_for(r):
    out = []
    if not r:
        return out
    if r["soil"] < 30: out.append({"level": "warn", "text": "Soil moisture is low. Consider irrigating."})
    if r["soil"] > 75: out.append({"level": "info", "text": "Soil is very wet. Pause irrigation."})
    if r["temp"] > 35: out.append({"level": "danger", "text": "High temperature. Watch for heat stress."})
    if r["rain"] >= 70: out.append({"level": "info", "text": "Rain is likely. Hold off watering."})
    return out


def log_pump(action, source):
    db().execute("INSERT INTO irrigation_log(ts,action,source) VALUES(?,?,?)", (iso(now()), action, source))


def pump_state():
    p = rows("SELECT is_on,mode FROM pump WHERE id=1")[0]
    return {"on": bool(p["is_on"]), "mode": p["mode"]}


def auto_irrigate(soil):
    p = pump_state()
    if p["mode"] != "auto":
        return
    want = soil < 35 if not p["on"] else soil < 55  # hysteresis: stop at 55%
    if want != p["on"]:
        db().execute("UPDATE pump SET is_on=? WHERE id=1", (int(want),))
        log_pump("ON" if want else "OFF", "auto")


def add_reading(temp, humidity, soil, rain):
    db().execute("INSERT INTO readings(ts,temp,humidity,soil,rain) VALUES(?,?,?,?,?)",
                 (iso(now()), temp, humidity, soil, rain))
    auto_irrigate(soil)
    db().commit()


@app.route("/")
def index():
    return render_template("index.html", today=datetime.now().strftime("%A, %B %d, %Y").upper())


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/api/summary")
def summary():
    r = latest()
    return jsonify(reading=r, alerts=alerts_for(r), pump=pump_state(), crops=rows("SELECT * FROM crops ORDER BY id"))


@app.get("/api/readings")
def readings():
    hrs = min(int(request.args.get("hours", 24)), 168)
    return jsonify(rows("SELECT * FROM readings WHERE ts>=? ORDER BY ts", (iso(now() - timedelta(hours=hrs)),)))


@app.post("/api/readings")
def post_reading():  # for real sensors / ESP32 / Raspberry Pi
    if API_KEY and request.headers.get("X-API-Key") != API_KEY:
        return jsonify(error="invalid API key"), 401
    d = request.get_json(force=True, silent=True) or {}
    try:
        add_reading(float(d["temp"]), float(d["humidity"]), float(d["soil"]), float(d.get("rain", 0)))
    except (KeyError, ValueError):
        return jsonify(error="send numeric temp, humidity, soil (rain optional)"), 400
    return jsonify(ok=True), 201


@app.post("/api/readings/simulate")
def simulate():
    r = latest() or {"temp": 28, "humidity": 64, "soil": 42, "rain": 25}
    pump_on = pump_state()["on"]
    soil = max(10, min(90, r["soil"] + (random.uniform(1, 4) if pump_on else random.uniform(-3, 1))))
    add_reading(round(max(15, min(42, r["temp"] + random.uniform(-1.5, 1.5))), 1),
                round(max(30, min(95, r["humidity"] + random.uniform(-3, 3))), 1), round(soil, 1),
                round(max(0, min(100, r["rain"] + random.uniform(-8, 8)))))
    return jsonify(ok=True)


@app.route("/api/crops", methods=["GET", "POST"])
def crops():
    if request.method == "POST":
        d = request.get_json(force=True, silent=True) or {}
        if not str(d.get("name", "")).strip():
            return jsonify(error="name required"), 400
        db().execute("INSERT INTO crops(name,field,stage,progress) VALUES(?,?,?,?)",
                     (d["name"].strip(), d.get("field", ""), d.get("stage", ""), max(0, min(100, int(d.get("progress", 0))))))
        db().commit()
        return jsonify(ok=True), 201
    return jsonify(rows("SELECT * FROM crops ORDER BY id"))


@app.route("/api/crops/<int:cid>", methods=["PUT", "DELETE"])
def crop(cid):
    if request.method == "DELETE":
        db().execute("DELETE FROM crops WHERE id=?", (cid,))
    else:
        p = max(0, min(100, int((request.get_json(force=True, silent=True) or {}).get("progress", 0))))
        db().execute("UPDATE crops SET progress=? WHERE id=?", (p, cid))
    db().commit()
    return jsonify(ok=True)


@app.route("/api/pump", methods=["GET", "POST"])
def pump():
    if request.method == "POST":
        d = request.get_json(force=True, silent=True) or {}
        if d.get("mode") in ("manual", "auto"):
            db().execute("UPDATE pump SET mode=? WHERE id=1", (d["mode"],))
            log_pump("MODE " + d["mode"].upper(), "user")
        if "on" in d:
            db().execute("UPDATE pump SET is_on=? WHERE id=1", (int(bool(d["on"])),))
            log_pump("ON" if d["on"] else "OFF", "user")
        db().commit()
    return jsonify(pump=pump_state(), log=rows("SELECT ts,action,source FROM irrigation_log ORDER BY id DESC LIMIT 8"))


@app.post("/api/advice")
def advice():
    d = request.get_json(force=True, silent=True) or {}
    crop_name, key = str(d.get("crop", "")).strip(), str(d.get("crop", "")).strip().lower()
    try:
        soil = float(d["soil"])
    except (KeyError, ValueError):
        return jsonify(error="enter a soil moisture number"), 400
    lo, hi = RANGES.get(key, (40, 60))
    if soil < lo: msg = f"Soil is dry for {crop_name or 'this crop'} (ideal {lo}-{hi}%). Irrigate soon."
    elif soil > hi: msg = f"Soil is wetter than ideal ({lo}-{hi}%). Pause irrigation and check drainage."
    else: msg = f"Moisture is within the ideal {lo}-{hi}% range. No action needed."
    return jsonify(advice=msg)


@app.get("/api/weather")
def weather():
    url = (f"https://api.open-meteo.com/v1/forecast?latitude={LAT}&longitude={LON}"
           "&current=temperature_2m,weather_code&daily=temperature_2m_max,precipitation_probability_max"
           "&timezone=auto&forecast_days=4")
    try:
        with urllib.request.urlopen(url, timeout=6) as r:
            return jsonify(live=True, **json.load(r))
    except Exception:
        return jsonify(live=False)


init_db()
if __name__ == "__main__":
    app.run(debug=True, port=int(os.environ.get("PORT", 5000)))
