const $ = s => document.querySelector(s);
const api = async (u, body, method) => {
  const o = body ? { method: method || "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : method ? { method } : undefined;
  const r = await fetch(u, o); const j = await r.json();
  if (!r.ok) throw new Error(j.error || "Request failed"); return j;
};
const esc = t => String(t ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const icon = c => c === 0 ? "☀" : c <= 3 ? "⛅" : c <= 48 ? "🌫" : c <= 67 ? "🌧" : c <= 77 ? "❄" : "⛈";
let chart;

async function refresh() {
  try {
    const s = await api("/api/summary"), r = s.reading;
    $("#status").textContent = "System online"; $("#status").className = "pill";
    if (r) { $("#s-temp").textContent = r.temp + "°C"; $("#s-hum").textContent = r.humidity + "%"; $("#s-soil").textContent = r.soil + "%"; $("#s-rain").textContent = r.rain + "%"; }
    $("#alerts").innerHTML = s.alerts.map(a => `<div class="alert ${a.level}">${esc(a.text)}</div>`).join("");
    $("#cropGrid").innerHTML = s.crops.map(c => `<div class="card"><b>${esc(c.name)}</b><small>${esc(c.stage)} · ${esc(c.field)}</small>
      <div class="bar"><i style="width:${c.progress}%"></i></div><div class="row"><small>Season progress ${c.progress}%</small>
      <button class="ghost" data-up="${c.id}">Update</button><button class="ghost" data-del="${c.id}">Remove</button></div></div>`).join("");
    pumpUI(s.pump); drawChart(); loadLog();
  } catch (e) { $("#status").textContent = "Offline"; $("#status").className = "pill off"; }
}
async function drawChart() {
  const d = await api("/api/readings?hours=24"), labels = d.map(x => new Date(x.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
  const ds = (l, k, c) => ({ label: l, data: d.map(x => x[k]), borderColor: c, tension: .3, pointRadius: 0 });
  const data = { labels, datasets: [ds("Soil %", "soil", "#2f7d46"), ds("Humidity %", "humidity", "#2b7bc0"), ds("Temp °C", "temp", "#e0782b")] };
  if (chart) { chart.data = data; chart.update(); } else chart = new Chart($("#chart"), { type: "line", data, options: { interaction: { mode: "index", intersect: false } } });
}
function pumpUI(p) { $("#pumpText").textContent = `Pump is currently ${p.on ? "ON" : "OFF"} (${p.mode} mode).`; $("#pumpBtn").textContent = p.on ? "Turn OFF" : "Turn ON"; $("#mode").value = p.mode; }
async function loadLog() {
  const d = await api("/api/pump");
  $("#log").innerHTML = d.log.length ? d.log.map(l => `<li>${new Date(l.ts).toLocaleString()} · ${esc(l.action)} <small>(${esc(l.source)})</small></li>`).join("") : "<li>No activity yet.</li>";
}
async function loadWeather() {
  const w = await api("/api/weather"); if (!w.live) { $("#weather").textContent = "Live weather unavailable (check internet / FARM_LAT, FARM_LON)."; return; }
  const days = w.daily.time.map((t, i) => `<div><small>${new Date(t).toLocaleDateString([], { weekday: "short" }).toUpperCase()}</small><br>${icon(w.current.weather_code)}<br>${Math.round(w.daily.temperature_2m_max[i])}°<br><small>${w.daily.precipitation_probability_max[i]}% rain</small></div>`);
  $("#weather").innerHTML = `<div><b style="font-size:28px">${Math.round(w.current.temperature_2m)}°</b><br><small>Now</small></div>` + days.join("");
}
$("#sim").onclick = async () => { await api("/api/readings/simulate", {}); refresh(); };
$("#pumpBtn").onclick = async () => { const s = await api("/api/summary"); await api("/api/pump", { on: !s.pump.on }); refresh(); };
$("#mode").onchange = async e => { await api("/api/pump", { mode: e.target.value }); refresh(); };
$("#cropForm").onsubmit = async e => { e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); await api("/api/crops", f); e.target.reset(); refresh(); };
$("#adviceForm").onsubmit = async e => { e.preventDefault(); try { $("#advice").textContent = (await api("/api/advice", Object.fromEntries(new FormData(e.target)))).advice; } catch (x) { $("#advice").textContent = x.message; } };
$("#cropGrid").onclick = async e => {
  const del = e.target.dataset.del, up = e.target.dataset.up;
  if (del && confirm("Remove this crop?")) { await api("/api/crops/" + del, null, "DELETE"); refresh(); }
  if (up) { const p = prompt("New season progress (0-100):"); if (p !== null) { await api("/api/crops/" + up, { progress: +p }, "PUT"); refresh(); } }
};
refresh(); loadWeather(); setInterval(refresh, 15000);
